module.exports = {
    "index" : (req,res)=>{
        res.send('hallo');
    }
}